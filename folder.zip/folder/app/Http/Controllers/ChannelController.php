<?php

namespace App\Http\Controllers;

use App\Models\Channel;
use Illuminate\Http\Request;

class ChannelController extends Controller
{
    public function store(Request $request): \Illuminate\Http\JsonResponse
    {
        $validatedData = $request->validate([
            'name' => ['required'],
            'slug' => ['required'],
            'customer_id' => ['required'],
            'locale' => ['required'],
            'currency' => ['required'],
            'URL' => ['required'],
            'type' => ['required'],
            'api_url' => ['nullable'],
            'admin_token' => ['nullable'],
            'api_key' => ['nullable'],
            'api_secret' => ['nullable'],
            'confirmation' => ['nullable'],
            'is_active' => ['required'],
        ]);

        if ($validatedData) {
            $channel = Channel::create($validatedData);
            if ($channel) {
                return response()->json(['message' => 'Channel created successfully', 'channel' => $channel], 201);
            } else {
                return response()->json(['message' => 'Failed to create Channel'], 500);
            }
        } else {
            return response()->json(['message' => 'Validation error', 'errors' => $request->errors()], 400);
        }
    }
public function index(): \Illuminate\Http\JsonResponse
{
    $channels = Channel::with('customer')->get();
    if ($channels) {
        return response()->json(['message' => 'Channels retrieved successfully', 'channels' => $channels], 200);
    } else {
        return response()->json(['message' => 'Error fetching channels'], 404);
    }
}
public function update(Request $request, $id): \Illuminate\Http\JsonResponse
{
    $channel = Channel::find($id);

    if (!$channel) {
        return response()->json(['message' => 'Channel not found'], 404);
    }

    $validatedData = $request->validate([
        'name' => ['required'],
        'slug' => ['required'],
        'customer_id' => ['required'],
        'locale' => ['required'],
        'currency' => ['required'],
        'URL' => ['required'],
        'type' => ['required'],

    ]);

    if ($validatedData) {
        $channel->update($validatedData);
        return response()->json(['message' => 'Channel updated successfully', 'channel' => $channel], 200);
    } else {
        return response()->json(['message' => 'Validation error', 'errors' => $request->errors()], 400);
    }
}
public function destroy($id): \Illuminate\Http\JsonResponse
{
    $channel = Channel::find($id);

    if (!$channel) {
        return response()->json(['message' => 'Channel not found'], 404);
    }

    $channel->delete();

    return response()->json(['message' => 'Channel deleted successfully'], 200);
}
public function show($id): \Illuminate\Http\JsonResponse
{
    $channel = Channel::with('customer')->find($id);

    if (!$channel) {
        return response()->json(['message' => 'Channel not found'], 404);
    }

    return response()->json(['message' => 'Channel retrieved successfully', 'channel' => $channel], 200);
}

}
