<template>
  <div class="root p-5">
    <div class="surface-ground">
      <div class="flex justify-content-between flex-wrap">
        <div class="flex justify-content-center align-item-center text-4xl text-black">
          Channels
        </div>
        <div class="flex justify-content-center align-item-center">
          <Button @click="visible = !visible">Create Channel</Button>
        </div>
        <Dialog v-model:visible="visible" modal header="Create Customer" :style="{ width: '50vw' }">
          <ChannelForm @handledRegistration="afterRegistration" />
        </Dialog>
      </div>
      <div class="surface-section p-4 mt-3">
        <DataTable
          v-model:selection="selectedProduct"
          :value="products"
          dataKey="id"
          paginator
          :rows="10"
          :rowsPerPageOptions="[10, 20, 30, 50]"
          tableStyle="min-width: 50rem"
        >
          <Column selectionMode="multiple" headerStyle="width: 3rem"></Column>
          <Column field="code" header="Name"></Column>
          <Column field="name" header="Customer Name"></Column>
          <Column field="category" header="Is Active"></Column>
          <Column field="quantity" header="Created At"></Column>
          <Column header="Action">
            <template #body="slotProps">
              <span
                class="pi pi-trash text-xl p-2 text-red-500 cursor-pointer"
                @click.prevent="slotProps.data;"
              ></span>
              <span
                class="pi pi-file-edit text-xl p-2 text-purple-500 cursor-pointer"
                @click.prevent="slotProps.data;"
              ></span>
            </template>
          </Column>
        </DataTable>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import ChannelForm from './components/ChannelForm.vue'
const visible = ref(false)
const products = ref()
const selectedProduct = ref()
const metaKey = ref(true)

const afterRegistration = () => {
  visible.value = false
}
</script>

<style scoped></style>
