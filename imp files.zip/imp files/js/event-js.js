$(document).ready(function () {
    var eventInputBoxes = $(".eventDate");
    var unknownButton = $("#unknown");
    var eventDateButton = $("#eventDate");
    var paidButton = $("#paidButton");
    var freeButton = $("#freeButton");
    var priceSlider = $(".sliderBox");
    var inPersonButton = $("#inPerson");
    var virtualButton = $("#virtual");
    var locationBox = $(".locationBox");

    // using the function for applying the effect
    unknownButton.click(function () {
        applyEffect(eventInputBoxes, unknownButton);
    });
    freeButton.click(function () {
        applyEffect(priceSlider, freeButton);
    });
    virtualButton.click(function () {
        applyEffect(locationBox, virtualButton);
    });

    // using the function for removing the effect
    eventDateButton.click(function () {
        removeEffect(eventInputBoxes, eventDateButton);
    });
    paidButton.click(function () {
        removeEffect(priceSlider, paidButton);
    });
    inPersonButton.click(function () {
        removeEffect(locationBox, inPersonButton);
    });
});

//-------function for applying the effect---------
function applyEffect(inputBoxes, button) {
    removePrimaryClass();
    inputBoxes.animate(
        {
            opacity: 0.5,
            blurRadius: 1,
        },
        {
            duration: "slow",
            step: function (now, fx) {
                if (fx.prop === "blurRadius") {
                    inputBoxes.addClass("blurred");
                }
            },
            complete: function () {
                inputBoxes.prop("disabled", true);
            },
        }
    );
    button.addClass("is-primary");
}

//   ----function for removing the effect---------
function removeEffect(inputBoxes, button) {
    removePrimaryClass();
    inputBoxes.animate(
        {
            opacity: 1,
            blurRadius: 0,
        },
        {
            duuration: "slow",
            step: function (now, fx) {
                if (fx.prop === "blurRadius") {
                    inputBoxes.removeClass("blurred");
                }
            },
            complete: function () {
                inputBoxes.prop("disabled", false);
                inputBoxes.eq(0).focus();
            },
        }
    );
    button.addClass("is-primary");
}
function removePrimaryClass() {
    $(".button").removeClass("is-primary");
}
$(document).ready(function () {
    var input = document.querySelector("#tag-input");
    new Tagify(input);
});
