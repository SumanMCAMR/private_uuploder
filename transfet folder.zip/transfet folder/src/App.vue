<template>
  <section>
    <div class="p-card-content">
      <router-view />
    </div>
  </section>
</template>

<script setup>
import { RouterView } from 'vue-router'
</script>
