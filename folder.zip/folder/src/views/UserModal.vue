<template>
  <div class="flex flex-grow-1 justify-content-center align-items-center h-auto mt-5 mb-5">
    <form
      class="flex flex-column gap-2 surface-section p-4 shadow-3 w-full border-round"
      @submit.prevent="handleRegistration"
    >
      <span class="p-float-label">
        <InputText
          id="name"
          v-model="name"
          type="text"
          class="inputBox"
          :class="{ 'p-invalid': nameError }"
          aria-describedby="text-error"
        />
        <label for="name">Name</label>
      </span>
      <small class="p-error" id="text-error">{{ nameError || '&nbsp;' }}</small>
      <span class="p-float-label">
        <InputText id="slug" v-model="slug" type="text" class="inputBox" readonly />
        <label for="name">Slug</label>
      </span>
      <span class="p-float-label mt-3">
        <AutoComplete
          id="dd"
          v-model="country"
          :suggestions="customerStore.filteredCountry"
          @complete="customerStore.search"
          :class="['w-full md:w-14rem', { 'p-invalid': countryError }]"
          aria-describedby="dd-error"
        />
        <label for="dd">Select a City</label>
      </span>
      <small class="p-error" id="dd-error">{{ countryError || '&nbsp;' }}</small>

      <label for="item" :class="{ 'p-error': buttonError }"> Is Active </label>
      <SelectButton
        id="item"
        v-model="is_active"
        :class="{ 'p-invalid': buttonError, 'custom-select-button': true }"
        aria-describedby="text-error"
        :options="options"
        optionLabel="label"
        :pt="{
          button: ({ context }) => ({
            class: context.active ? 'bg-primary border-900' : undefined
          })
        }"
      />
      <small class="p-error">{{ buttonError || '&nbsp;' }}</small>
      <Button type="submit" label="Submit" />
    </form>
  </div>
</template>

<script setup>
import { defineProps, defineEmits, ref, onMounted, watch } from 'vue'
import { useField, useForm } from 'vee-validate'
import { useValidation } from '../store/ValidationStore'
import { useCustomerStore } from '../store/CustomerStore'

const formStore = useValidation()
const customerStore = useCustomerStore()
const { handleSubmit, resetForm } = useForm()
const slug = ref('')
const options = [
  { label: 'Yes', value: true },
  { label: 'No', value: false }
]
const emits = defineEmits(['handledRegistration'])
const { value: name, errorMessage: nameError } = useField('name', formStore.validateName)
const { value: country, errorMessage: countryError } = useField(
  'country',
  formStore.validateCountry
)
const { value: is_active, errorMessage: buttonError } = useField(
  'is_active',
  formStore.validateButton
)

watch(name, (newName) => {
  slug.value = customerStore.generateSlug(newName)
})

onMounted(() => {
  customerStore.fetchCountry()
})

const handleRegistration = handleSubmit((value) => {
  const formdata = {
    name: name.value,
    slug: slug.value,
    country: country.value,
    is_active: is_active.value.value
  }
  console.table(formdata)
  emits('handledRegistration')
})
</script>

<style scoped>
.inputBox {
  width: 100%;
}
.p-error {
  margin-bottom: 10px;
}
</style>
