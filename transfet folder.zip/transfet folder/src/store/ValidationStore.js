import { defineStore } from 'pinia'
import { useCustomerStore } from './CustomerStore'
import { UseChannelStore } from './ChannelStore'

export const useValidation = defineStore('formStore', {
  state: () => ({}),
  actions: {
    validateName(value) {
      if (!value || value.trim() === '') {
        return 'Name is required.'
      }
      return true
    },
    validateCountry(value) {
      const externalStore = useCustomerStore()
      const countryArray = externalStore.country
      if (!value) {
        return 'City is required.'
      } else if (!countryArray.includes(value)) {
        return 'Invalid country selected.'
      }

      return true
    },
    validateButton(value) {
      if (!value) {
        return 'Active state is required.'
      }
      return true
    },
    validateCustomer(value) {
      const externalStore = UseChannelStore()
      const countryArray = externalStore.customers
      if (!value) {
        return 'City is required.'
      }
      // }else if (!countryArray.includes(value)) {
      //     return 'Invalid country selected.';
      // }

      return true
    },
    validateLocale(value) {
      if (!value) {
        return 'Locale is required!'
      }
      return true
    },
    validateCurrency(value) {
      if (!value) {
        return 'Currency is required!'
      }
      return true
    },
    validateURL(value) {
      if (!value) {
        return 'URL is required!'
      }
      return true
    },
    validateType(value) {
      if (!value) {
        return 'Please select a type!'
      }
      return true
    }
  }
})
