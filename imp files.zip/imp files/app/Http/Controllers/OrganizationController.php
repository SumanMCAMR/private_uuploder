<?php

namespace App\Http\Controllers;

use App\Models\Note;
use App\Models\Organization;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;
use Illuminate\Support\Facades\Validator;

class OrganizationController extends Controller
{
    public function addOrganization(Request $request){
        try {
            $validator = Validator::make($request->all(), [
                'name' => 'required|string|max:255|min:5|unique:organizations',
                'address' => 'required|string',
                'note' => 'required|string|max:255',
                'slug' => 'required|string'
            ]);

            $validator->validate();

            $organization = new Organization($request->all());
            $organization->slug = $request->input('slug');
            $organization->save();
//            ---------------------
            $note = new Note();
            $note->note = $request->input('note');
            $organization->note()->save($note);

            return response()->json(['success' => 'Organization added successfully'], 200);
        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        }
    }
}