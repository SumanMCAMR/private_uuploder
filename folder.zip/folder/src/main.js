import { createApp } from 'vue'
import { createPinia } from 'pinia'
import router from './router'
import 'primeicons/primeicons.css'
import './main.css'
import App from './App.vue'
import PrimeVue from 'primevue/config'
import 'primevue/resources/themes/bootstrap4-light-purple/theme.css'
import ToastService from 'primevue/toastservice'

import Checkbox from 'primevue/checkbox'
import Button from 'primevue/button'
import InputText from 'primevue/inputtext'
import Password from 'primevue/password'
import FileUpload from 'primevue/fileupload'
import DataTable from 'primevue/datatable'
import Column from 'primevue/column'
import Dialog from 'primevue/dialog'
import AutoComplete from 'primevue/autocomplete'
import SelectButton from 'primevue/selectbutton'
import Dropdown from 'primevue/dropdown'
import Tag from 'primevue/tag'

const pinia = createPinia()
const APP = createApp(App)

APP.use(PrimeVue)
APP.use(ToastService)
APP.use(pinia)
APP.use(router)
APP.component('Button', Button)
APP.component('DataTable', DataTable)
APP.component('Column', Column)
APP.component('InputText', InputText)
APP.component('Checkbox', Checkbox)
APP.component('Password', Password)
APP.component('FileUpload', FileUpload)
APP.component('Dialog', Dialog)
APP.component('AutoComplete', AutoComplete)
APP.component('SelectButton', SelectButton)
APP.component('Dropdown', Dropdown)
APP.component('Tag', Tag)

APP.mount('#app')
