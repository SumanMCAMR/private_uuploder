$(document).ready(function () {
    var eventInputBoxes = $(".eventDate");
    var unknownButton = $("#unknown");
    var eventDateButton = $("#eventDate");
    var paidButton = $("#paidButton");
    var freeButton = $("#freeButton");
    var priceSlider = $(".sliderBox");
    var inPersonButton = $("#inPerson");
    var virtualButton = $("#virtual");
    var locationBox = $(".locationBox");

    // using the function for applying the effect
    unknownButton.click(function () {
        applyEffect(eventInputBoxes, unknownButton, eventDateButton);
    });
    freeButton.click(function () {
        applyEffect(priceSlider, freeButton, paidButton);
    });
    virtualButton.click(function () {
        applyEffect(locationBox, virtualButton, inPersonButton);
    });

    // using the function for removing the effect
    eventDateButton.click(function () {
        removeEffect(eventInputBoxes, eventDateButton, unknownButton);
    });
    paidButton.click(function () {
        removeEffect(priceSlider, paidButton, freeButton);
    });
    inPersonButton.click(function () {
        removeEffect(locationBox, inPersonButton, virtualButton);
    });
});

//-------function for applying the effect---------
function applyEffect(inputBoxes, button1, button2) {
    togglePrimaryButton(button1, button2);
    inputBoxes.animate(
        {
            opacity: 0.5,
            blurRadius: 1,
        },
        {
            duration: "slow",
            step: function (now, fx) {
                if (fx.prop === "blurRadius") {
                    inputBoxes.addClass("blurred");
                }
            },
            complete: function () {
                inputBoxes.prop("disabled", true);
            },
        }
    );
}

//   ----function for removing the effect---------
function removeEffect(inputBoxes, button1, button2) {
    togglePrimaryButton(button1, button2);
    inputBoxes.animate(
        {
            opacity: 1,
            blurRadius: 0,
        },
        {
            duuration: "slow",
            step: function (now, fx) {
                if (fx.prop === "blurRadius") {
                    inputBoxes.removeClass("blurred");
                }
            },
            complete: function () {
                inputBoxes.prop("disabled", false);
                inputBoxes.eq(0).focus();
            },
        }
    );
}
function togglePrimaryButton(selectedButton, otherButton) {
    $(selectedButton).addClass("is-primary");
    $(otherButton).removeClass("is-primary");
}

$(document).ready(function () {
    var input = document.querySelector("#tag-input");
    var tagify = new Tagify(input);

    tagify.on("tag", function (e) {
        var tagsInput = tagify.DOM.input;
        var tags = tagify.value.map((tag) => tag.value).join(", "); // Get plain text tags
        tagsInput.value = tags; // Set plain text tags to the input field
    });
    // ---------checkbox logic----------------
    $("#selectAll").change(function () {
        console.log("select all");
        $(".checkboxes").prop("checked", this.checked);
    });
});
