<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Organization;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AuthController extends Controller
{
    public function loginPage()
    {
        return view('login');
    }
    public function index(){
       $organization= Organization::pluck('name','id');
        return view('home',['organization'=>$organization]);
    }

    public function registerPage()
    {
        return view('register');
    }

    public function login(Request $request)
    {
        $credentials = $request->validate([
            'email'=>['required','email'],
            'password'=>['required']
        ]);
        if(Auth::attempt($credentials)){
            $request->session()->regenerate();
            return redirect('/')->with(['success'=>'Login Successful']);
        }
        return back()->withErrors(['error'=>'Incorrect credentials'])->onlyInput();
    }
    public function register(Request $request){
        $user_details = $request->validate([
            'name'=>['required','min:5','max:50','string'],
            'email'=>['required','email','unique:users'],
            'password'=>['required','min:6','max:64']
        ]);
        $user = User::create($user_details);
        if (!$user){return redirect()->back()->withErrors('error','Something wrong please try again');}
        Auth::login($user);
        return redirect(route('home'))->with(['success'=>'Successfully registered']);
    }
    public function logout(){
        Auth::logout();
        return redirect(route('login-page'));
    }
}