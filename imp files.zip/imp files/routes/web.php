<?php

use App\Http\Controllers\AuthController;
use App\Http\Controllers\EventController;
use App\Http\Controllers\OrganizationController;
use Illuminate\Support\Facades\Route;

Route::get('/', [AuthController::class, 'index'])->name('home');
Route::middleware('auth')->group(function () {
    Route::get('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

});
Route::get('/login', [AuthController::class, 'loginPage'])->name('login-page');
Route::post('/login', [AuthController::class, 'login'])->name('login');
Route::get('/register', [AuthController::class, 'registerPage'])->name('register-page');
Route::post('/register', [AuthController::class, 'register'])->name('register');

Route::post('/org/add', [OrganizationController::class, 'addOrganization'])->name('addOrganization');
Route::post('/event/add', [EventController::class, 'addEvent'])->name('addEvent');
Route::get('/event/edit/{id}', [EventController::class, 'editEvent'])->name('editEvent');
Route::put('/event/edit/{id}', [EventController::class, 'updateEvent'])->name('updateEvent');
Route::delete('/event/delete/{id}', [EventController::class, 'deleteEvent'])->name('deleteEvent');