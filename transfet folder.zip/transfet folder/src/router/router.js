import { createRouter, createWebHistory } from 'vue-router'
import Customer from '../views/Customer.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      component: Customer,
      name: 'home'
    },
    {
      path: '/channel',
      component: () => import('../views/Channel.vue'),
      name: 'channel'
    }
  ]
})

export default router
