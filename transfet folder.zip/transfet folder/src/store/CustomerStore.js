import { defineStore } from 'pinia'
import axios from 'axios'

export const useCustomerStore = defineStore('CustomerStore', {
  state: () => ({
    country: [],
    filteredCountry: [],
    response: false,
    Customers: [],
    createdDate: 0
  }),
  actions: {
    fetchCountry() {
      axios.get('https://restcountries.com/v3.1/all?fields=name').then((response) => {
        console.log(response)
        let countryName = response.data.map((country) => country.name.common)
        this.country = countryName
      })
    },
    search(event) {
      const maxSuggestions = 5
      this.filteredCountry = this.country
        .filter((country) => country.toLowerCase().startsWith(event.query.toLowerCase()))
        .slice(0, maxSuggestions)
    },
    generateSlug(str) {
      return str.toLowerCase().replace(/\s+/g, '-')
    },
    handleCreate(data) {
      axios
        .post('http://127.0.0.1:8000/api/customers', data)
        .then((response) => {
          console.log(response)
          if (response.status === 201) {
            this.response = true
          }
        })
        .catch((error) => {
          console.log(error)
        })
    },
    fetchCustomers() {
      axios
        .get('http://127.0.0.1:8000/api/customers')
        .then((response) => {
          console.log(response.data.customers)
          this.Customers = response.data.customers
        })
        .catch((error) => {
          console.log(error)
        })
    }
  }
})
