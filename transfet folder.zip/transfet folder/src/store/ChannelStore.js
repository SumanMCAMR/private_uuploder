import { defineStore } from 'pinia'
import axios from 'axios'

export const UseChannelStore = defineStore('CustomerStore', {
  state: () => ({
    customers: [],
    filteredCustomers: [],
    response: false
  }),
  actions: {
    fetchCustomers() {
      axios.get('http://127.0.0.1:8000/api/customer-names').then((response) => {
        console.log(response)
        let customerName = response.data.customer_names
        this.customers = Object.values(customerName)
      })
    },
    search(event) {
      const maxSuggestions = 5
      this.filteredCustomers = this.customers
        .filter((name) => name.toLowerCase().startsWith(event.query.toLowerCase()))
        .slice(0, maxSuggestions)
    },
    generateSlug(str) {
      return str.toLowerCase().replace(/\s+/g, '-')
    },
    handleCreateChannel(data) {
      axios
        .post('http://127.0.0.1:8000/api/channels', data)
        .then((response) => {
          console.log(response)
          if (response.status === 201) {
            this.response = true
          }
        })
        .catch((error) => {
          console.log(error)
        })
    }
  }
})
