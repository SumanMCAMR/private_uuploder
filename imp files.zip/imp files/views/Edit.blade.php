@extends('layout.main')
@section('title', 'Edit Customer')
@section('content')
    <section class="section">
        <div class="container">
            <div class="title has-text-primary">Edit Customer</div>
            <form action="{{ route('update', ['c_id' => $customer->c_id]) }}" method="POST">
            @csrf
            @method('PUT') <!-- Use PUT method for updates -->
                <div class="field">
                    <label class="label">Name</label>
                    <div class="control">
                        <input class="input" type="text" name="name" value="{{ $customer->name }}" required>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Email</label>
                    <div class="control">
                        <input class="input" type="email" name="email" value="{{ $customer->email }}" required>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Phone</label>
                    <div class="control">
                        <input class="input" type="text" name="phone" value="{{ $customer->phone }}" required>
                    </div>
                </div>
                <div class="field">
                    <label class="label">DOB</label>
                    <div class="control">
                        <input class="input" type="date" name="DOB" value="{{ $customer->DOB }}" required>
                    </div>
                </div>
                <div class="field is-grouped">
                    <div class="control">
                        <button class="button is-primary">Update</button>
                    </div>
                    <div class="control">
                        <a href="{{ route('home') }}" class="button is-link">Cancel</a>
                    </div>
                </div>
            </form>
        </div>
    </section>
@endsection