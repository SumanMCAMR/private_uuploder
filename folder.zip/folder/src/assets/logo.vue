<template>
  <span
    to="registration"
    class="landing-title font-bold m-0 mt-5 text-4xl lg:text-5xl text-primary"
  >
    Asset
  </span>
</template>
