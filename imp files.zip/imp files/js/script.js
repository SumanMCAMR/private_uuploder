$("#add-organization").click(function () {
    $("#modal-add-organization").addClass("is-active");
});
$("#add-event").click(function () {
    $("#modal-add-event").addClass("is-active");
});

let errorBox = ["nameError", "addressError", "noteError", "slugError"];
$(".modal-close,.cancel").click(function () {
    $("#add-organization-form")[0].reset();
    $.each(errorBox, function (index, error) {
        $("#" + error).text("");
    });
    $("#modal-add-organization").removeClass("is-active");
    alertify.error("cancelled");
});
$(document).on("click", "#close-event, #cancelButtonEvent", function () {
    // $("#add-event-form")[0].reset();
    // $.each(errorBox, function (index, error) {
    //     $("#" + error).text("");
    // });
    $("#modal-add-event").removeClass("is-active");
    alertify.error("cancelled");
    console.log("cancelled");
});

// -----------submit function for organization----------------
$("#add-organization-form").submit("click", function (e) {
    e.preventDefault();
    let formdata = new FormData(this);
    console.log(formdata);
    $.ajax({
        url: "/org/add",
        method: "POST",
        processData: false,
        contentType: false,
        data: formdata,
        success: function (response) {
            if (response) {
                $("#add-organization-form")[0].reset();
                $("#modal-add-organization").removeClass("is-active");
                alertify.success(response.success);
            } else {
                console.log("Unexpected response format");
            }
        },
        error: function (xhr) {
            if (xhr.status === 422) {
                let errors = xhr.responseJSON.errors;
                console.log(errors);
                $.each(errors, function (field, error) {
                    $("#" + field + "Error").text(error[0]);
                    console.log(error[0]);
                });
            } else {
                console.log(xhr);
            }
        },
    });
});
