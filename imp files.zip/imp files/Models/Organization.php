<?php

namespace App\Models;

use GuzzleHttp\Psr7\Request;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;

class Organization extends Model
{
    use HasFactory;

    protected $table = 'organizations';

    protected $fillable = [
        'name',
        'address',
        'slug'
    ];
    public function setSlugAttribute($value){
        $this->attributes['slug']= Str::slug($value);
    }
    public function note(){
        return $this->morphOne(Note::class,'notable');
    }
}