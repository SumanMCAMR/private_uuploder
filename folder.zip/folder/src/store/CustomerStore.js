import { defineStore } from 'pinia'
import axios from 'axios'

export const useCustomerStore = defineStore('CustomerStore', {
  state: () => ({
    country: [],
    filteredCountry: [],
    response: false,
    Customers: [],
    createdDate: 0,
    loading: false
  }),
  actions: {
    fetchCountry() {
      this.loading= true
      axios.get('https://restcountries.com/v3.1/all?fields=name').then((response) => {
        console.log(response)
        let countryName = response.data.map((country) => country.name.common)
        this.country = countryName
        this.loading=false
      })
    },
    search(event) {
      const maxSuggestions = 5
      this.filteredCountry = this.country
        .filter((country) => country.toLowerCase().startsWith(event.query.toLowerCase()))
        .slice(0, maxSuggestions)
    },
    generateSlug(str) {
      return str.toLowerCase().replace(/\s+/g, '-')
    },
    async handleCreate(data) {
      return new Promise((resolve, reject) => {
        axios
          .post('http://127.0.0.1:8000/api/customers', data)
          .then((response) => {
            console.log(response)
            if (response.status === 201) {
              this.response = true
              resolve(response)
            } else {
              reject(new Error('Failed to create channel'))
            }
          })
          .catch((error) => {
            console.log(error)
          })
      })
    },
    fetchCustomers() {
      axios
        .get('http://127.0.0.1:8000/api/customers')
        .then((response) => {
          console.log(response.data.customers)
          this.Customers = response.data.customers
        })
        .catch((error) => {
          console.log(error)
        })
    },
    calculateElapsedTime(createdAt) {
      console.log('createdAt:', createdAt)
      const createdDate = new Date(createdAt)
      const currentDate = new Date()
      const timeDifferenceInMilliseconds = currentDate - createdDate
      return Math.floor(timeDifferenceInMilliseconds / (1000 * 60 * 60 * 24))
    },
    deleteCustomer(id) {
      const filteredCustomers = this.Customers.filter((u) => u.id !== id)
      this.Customers = filteredCustomers
      console.log('filtered customers', filteredCustomers)
    }
  }
})
