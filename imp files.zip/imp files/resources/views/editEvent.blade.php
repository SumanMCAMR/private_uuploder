@extends('layout.main')
@section('title', 'Edit Event')
@section('content')
<section class="section">
    <div class="container">
        <div class="title has-text-primary">Edit Event</div>
        <form action="{{ route('editEvent', ['id' => $event->id]) }}" method="POST">
            @csrf
            @method('PUT')
            <div class="field">
                <label class="label" for="event_name">Event Name</label>
                <div class="control">
                    <input class="input" id="event_name" name="event_name" type="text" value="{{$event->event_name}}" />
                    @error('event_name')
                    <span class="help is-danger" id="event_nameError"> {{$message}} </span>
                    @enderror
                </div>
            </div>
            <div class="field">
                <label class="label">Organization Name</label>
                <div class="control">
                    <div class="select">
                        <select name="organization_id">
                            <option value="" disabled selected>
                                Select an organization
                            </option>
                            @foreach ($organization as $id => $name)
                            <option value="{{ $id }}" {{ $event->organization_id == $id ? 'selected' : '' }}>
                                {{ $name }}
                            </option>
                            @endforeach
                        </select>
                        @error('organization_id')
                        <span class="help is-danger" id="event_nameError"> {{$message}} </span>
                        @enderror
                    </div>
                </div>
            </div>
            <div class="field">
                <label class="label">Event Description</label>
                <div class="control">
                    <textarea class="textarea" name="event_description">{{ $event->event_description }}</textarea>
                </div>
                @error('event_description')
                <p class="help is-danger">{{ $message }}</p>
                @enderror
            </div>

            <div class="field">
                <label class="label">Event Type</label>
                <div class="buttons has-addons">
                    <button class="button" type="button" id="inPerson" name="event_type" value="in_person">
                        In-person
                    </button>
                    <button class="button" type="button" id="virtual" name="event_type" value="virtual">
                        Virtual
                    </button>
                </div>
            </div>
            <div class="field">
                <label class="label">Location</label>
                <div class="control">
                    <input class="input locationBox" name="event_location" type="text"
                        value="{{$event->event_location}}" />
                    @error('event_location')
                    <span class="help is-danger" id="event_locationError">{{$message}}</span>
                    @enderror
                </div>
            </div>
            <div class="field">
                <label class="label">Topic</label>
                <div class="control">
                    <input class="input" type="text" name="tags" id="tag-input" placeholder="Enter tags..."
                        value="{{$event->tags}}" />
                </div>
            </div>
            <div class="field">
                <label class="label">Price</label>
                <div class="buttons has-addons">
                    <button class="button" type="button" id="paidButton" name="pay_type" value="paid">Paid
                    </button>
                    <button class="button" type="button" id="freeButton" name="pay_type" value="free">Free
                    </button>
                </div>
                <div class="control">
                    <span class="help">Please choose the range between 500 to 3000</span>
                    <input class="slider sliderBox" type="range" name="price" min="500" max="3000"
                        value="{{$event->price}}" />
                </div>
            </div>
            <div class="field">
                <label class="label">Event Date</label>
                <div class="buttons has-addons">
                    <button class="button" type="button" id="eventDate" name="event_date" value="known">Event
                        Date
                    </button>
                    <button class="button" type="button" id="unknown" name="event_date" value="unknown">
                        Unknown
                    </button>
                </div>
                <div class="field is-grouped" id="dateInputBoxes">
                    <div class="control">
                        <input class="input eventDate" name="start_date" type="date" value="{{$event->start_date}}" />
                        @error('start_date')
                        <span class="help is-danger" id="start_dateError">{{$message}}</span>
                        @enderror
                    </div>
                    <div class="control">
                        <input class="input eventDate" name="end_date" type="date" value="{{$event->end_date}}" />
                        @error('end_date')
                        <span class="help is-danger" id="end_dateError">{{$message}}</span>
                        @enderror
                    </div>
                </div>
            </div>
            <div class="field">
                <label class="label">Notes</label>
                <div class="control">
                    <input class="input" type="text" name="event_note" value="{{$event->note->note}}" />
                    @error('event_note')
                    <span class="help is-danger" id="event_noteError">{{$message}}</span>
                    @enderror
                </div>
            </div>
            <div class="field">
                <label class="label">Accept Speaker Application?</label>
                <div class="control">
                    <label class="checkbox">
                        <input type="checkbox" name="is_speaker" value="1" {{ $event->is_speaker ? 'checked' : '' }}/>
                        Yes
                    </label>
                </div>
            </div>
            <button class="button is-primary" type="submit">Submit</button>
            <a class="button is-danger" href="{{ route('home') }}">Cancel</a>

        </form>
    </div>
</section>
@endsection