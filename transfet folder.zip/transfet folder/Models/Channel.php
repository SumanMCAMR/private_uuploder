<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Channel extends Model
{
    use HasFactory;
    protected $fillable = [
        'name',
        'slug',
        'customer_id',
        'locale',
        'currency',
        'URL',
        'type',
        'api_url',
        'admin_token',
        'api_key',
        'api_secret',
        'confirmation',
        'is_active',
    ];
    public function customer(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }
}
