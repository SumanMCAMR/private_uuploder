@stack('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
<script src="https://cdn.datatables.net/v/dt/jqc-1.12.4/dt-1.13.6/b-2.4.1/sl-1.7.0/datatables.min.js"></script>
<script>
    $(document).ready(function() {
        $(".navbar-burger").click(function() {
            $(".navbar-burger, .navbar-menu", $(this).closest('.navbar')).toggleClass("is-active");
        });
    });
</script>