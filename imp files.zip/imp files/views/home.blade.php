@extends('layout.main') @section('title') Home page @endsection
@section('content')
<section class="section">
    <div class="container">
        <div class="header-content p-2 mb-4">
            <span class="title has-text-primary mr-5"
                >Events & Organizations</span
            >
            <span class="button is-info is-hovarable" id="add-event"
                ><strong>Add Events</strong></span
            >
            <span class="button is-primary is-hovarable" id="add-organization"
                ><strong>Add org</strong></span
            >
        </div>
        <div class="filter has-background-primary-light pl-4 mb-5 mt-5">
            <span>Filter By :</span>
        </div>
    </div>
</section>

{{-- ---------------add organization modal-----------}}
<div id="modal-add-organization" class="modal">
    <div class="modal-background"></div>

    <div class="modal-content">
        <div class="box">
            <h1 class="title is-4 has-text-primary">Add Organization</h1>
            <div class="form">
                <form id="add-organization-form">
                    <div class="field">
                        @csrf
                        <label class="label">Org Name</label>
                        <div class="control">
                            <input
                                class="input"
                                type="text"
                                name="name"
                                value="{{ old('name') }}"
                                required
                            />
                        </div>
                        <span
                            class="help has-text-danger"
                            id="nameError"
                        ></span>
                    </div>
                    <div class="field">
                        <label class="label">Address</label>
                        <div class="control">
                            <input
                                class="input"
                                type="text"
                                name="address"
                                value="{{ old('address') }}"
                                required
                            />
                        </div>
                        <span
                            class="help has-text-danger"
                            id="addressError"
                        ></span>
                    </div>
                    <div class="field">
                        <label class="label">Notes</label>
                        <div class="control">
                            <input
                                class="input"
                                type="text"
                                name="note"
                                value="{{ old('note') }}"
                                required
                            />
                        </div>
                        <span
                            class="help has-text-danger"
                            id="noteError"
                        ></span>
                    </div>
                    <div class="field">
                        <label class="label">Slug</label>
                        <div class="control">
                            <input
                                class="input"
                                type="text"
                                name="slug"
                                value="{{ old('Slug') }}"
                                required
                            />
                        </div>
                        <span
                            class="help has-text-danger"
                            id="slugError"
                        ></span>
                    </div>
                    <div class="field is-grouped">
                        <div class="control">
                            <button class="button is-primary">Save</button>
                        </div>
                        <div class="control">
                            <button class="button is-link cancel" type="button">
                                Cancel
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <button class="modal-close is-large" aria-label="close"></button>
</div>
<script src="js/script.js"></script>
{{-- ---------------end organization modal-----------}}

{{-- ---------------add event modal-----------}}
<div class="modal" id="modal-add-event">
    <div class="modal-background"></div>
    <div class="modal-card">
        <header class="modal-card-head">
            <p class="modal-card-title">Create an Event</p>
            <button class="delete" id="close-event" aria-label="close"></button>
        </header>
        <section class="modal-card-body">
            <div class="field">
                <label class="label">Event Name</label>
                <div class="control">
                    <input class="input" name="event_name" type="text" />
                </div>
            </div>
            <div class="field">
                <label class="label">Organization Name</label>
                <div class="control">
                    <div class="select">
                        <select name="organization_id">
                            <option value="" disabled selected>
                                Select an organization
                            </option>
                            @foreach ($organization as $id => $name)
                            <option value="{{ $id }}">{{ $name }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
            </div>
            <div class="field">
                <label class="label">Event Description</label>
                <div class="control">
                    <textarea
                        class="textarea"
                        name="event_description"
                    ></textarea>
                </div>
            </div>
            <div class="field">
                <label class="label">Event Type</label>
                <div class="buttons has-addons">
                    <button class="button" id="inPerson">In-person</button>
                    <button class="button" id="virtual">Virtual</button>
                </div>
            </div>
            <div class="field">
                <label class="label">Location</label>
                <div class="control">
                    <input
                        class="input locationBox"
                        name="event_location"
                        type="text"
                    />
                </div>
            </div>
            <div class="field">
                <label class="label">Topic</label>
                <div class="control">
                    <input
                        class="input"
                        type="text"
                        name="tags"
                        id="tag-input"
                        placeholder="Enter tags..."
                    />
                </div>
            </div>
            <div class="field">
                <label class="label">Price</label>
                <div class="buttons has-addons">
                    <button class="button" id="paidButton">Paid</button>
                    <button class="button" id="freeButton">Free</button>
                </div>
                <div class="control">
                    <input
                        class="slider sliderBox"
                        type="range"
                        name="price"
                        min="500"
                        max="3000"
                    />
                </div>
            </div>
            <div class="field">
                <label class="label">Event Date</label>
                <div class="buttons has-addons">
                    <button class="button" id="eventDate">Event Date</button>
                    <button class="button" id="unknown">Unknown</button>
                </div>
                <div class="field is-grouped" id="dateInputBoxes">
                    <div class="control">
                        <input
                            class="input eventDate"
                            name="start_date"
                            type="date"
                        />
                    </div>
                    <div class="control">
                        <input
                            class="input eventDate"
                            name="end_date"
                            type="date"
                        />
                    </div>
                </div>
            </div>
            <div class="field">
                <label class="label">Notes</label>
                <div class="control">
                    <input class="input" type="text" name="note" />
                </div>
            </div>
            <div class="field">
                <label class="label">Accept Speaker Application?</label>
                <div class="control">
                    <label class="checkbox">
                        <input type="checkbox" name="speaker" />
                        Yes
                    </label>
                </div>
            </div>
        </section>
        <footer class="modal-card-foot">
            <button class="button is-primary">Publish</button>
            <button class="button" id="cancelButtonEvent">Cancel</button>
        </footer>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>
<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
<script src="js/event-js.js"></script>
@endsection
