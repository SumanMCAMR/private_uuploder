<template>
  <div class="flex flex-grow-1 justify-content-center align-items-center h-auto mb-1">
    <form
      class="flex flex-column gap-2 surface-section p-4 shadow-3 w-full border-round align-items-center"
      @submit.prevent="handleCreateChannel"
    >
      <span class="p-float-label">
        <InputText
          id="name"
          v-model="name"
          type="text"
          :class="['w-full md:w-14rem', { 'p-invalid': nameError }]"
          aria-describedby="text-error"
        />
        <label for="name">Channel Name</label>
      </span>
      <small class="p-error" id="text-error">{{ nameError || '&nbsp;' }}</small>
      <span class="p-float-label">
        <InputText id="slug" v-model="slug" type="text" class="w-full md:w-14rem" readonly />
        <label for="name">Slug</label>
      </span>
      <span class="p-float-label mt-3">
        <AutoComplete
          id="dd"
          v-model="Customer"
          :suggestions="channelStore.filteredCustomers"
          optionLabel="name"
          @complete="channelStore.search"
          :inputStyle="{ width: '14rem' }"
          :class="['w-full', { 'p-invalid': customerError }]"
          aria-describedby="customerError"
          @item-select="channelStore.handleCustomerSelect"
          :disabled="aucompleteDisable"
        />
        <label for="dd">Select a Customer</label>
      </span>
      <small class="p-error" id="customerError">{{ customerError || '&nbsp;' }}</small>

      <span class="p-float-label mt-3">
        <Dropdown
          v-model="Locale"
          inputId="Locale"
          :options="LocaleName"
          placeholder="Select Locale"
          :class="['w-full md:w-14rem', { 'p-invalid': localeError }]"
          aria-describedby="localeError"
        />
        <label for="Locale">Select Locale</label>
      </span>
      <small class="p-error" id="localeError">{{ localeError || '&nbsp;' }}</small>

      <span class="p-float-label mt-3">
        <Dropdown
          v-model="currency"
          inputId="currencyId"
          :options="CurrencyName"
          placeholder="Select Currency"
          :class="['w-full md:w-14rem', { 'p-invalid': currencyError }]"
          aria-describedby="currencyError"
        />
        <label for="currencyId">Select Currency</label>
      </span>
      <small class="p-error" id="currencyError">{{ currencyError || '&nbsp;' }}</small>

      <span class="p-float-label">
        <InputText
          id="URL"
          v-model="URL"
          type="text"
          :class="['w-full md:w-14rem', { 'p-invalid': urlError }]"
          aria-describedby="urlError"
        />
        <label for="URL">Store URL</label>
      </span>
      <small class="p-error" id="urlError">{{ urlError || '&nbsp;' }}</small>

      <span class="p-float-label mt-3">
        <Dropdown
          v-model="type"
          inputId="typeId"
          :options="Types"
          placeholder="Select Type"
          :class="['w-full md:w-14rem', { 'p-invalid': typeError }]"
          aria-describedby="typeError"
        />
        <label for="typeId">Select Type</label>
      </span>
      <small class="p-error" id="tpeError">{{ typeError || '&nbsp;' }}</small>

      <div class="small-form p-card flex justify-content-center" v-if="type !== undefined">
        <form class="p-card-body">
          <span class="p-card-title flex justify-content-center">Api Keys</span>
          <div class="p-field" v-if="type === 'Bigcommerce'">
            <span class="p-float-label mt-3">
              <InputText id="url" v-model="apiURL" />
              <label for="url">URL</label>
            </span>
          </div>
          <div class="p-field">
            <span class="p-float-label mt-3">
              <InputText id="adminToken" v-model="adminToken" />
              <label for="adminToken">Admin API Token</label>
            </span>
          </div>

          <div class="p-field">
            <span class="p-float-label mt-3">
              <InputText id="apiKey" v-model="apiKey" />
              <label for="apiKey">API Key</label>
            </span>
          </div>

          <div class="p-field" v-if="type !== 'Shopify'">
            <span class="p-float-label mt-3">
              <InputText id="apiSecret" v-model="apiSecret" />
              <label for="apiSecret">API Secret</label>
            </span>
          </div>
        </form>
      </div>
      <label for="item" :class="{ 'p-error': buttonError }"> Is Active </label>
      <SelectButton
        id="item"
        v-model="is_active"
        :class="{ 'p-invalid': buttonError, 'custom-select-button': true }"
        aria-describedby="text-error"
        :options="options"
        optionLabel="label"
        :pt="{
          button: ({ context }) => ({
            class: context.active ? 'bg-primary border-900' : undefined
          })
        }"
      />
      <small class="p-error">{{ buttonError || '&nbsp;' }}</small>

      <label for="confirmation">Ask confirmation popup every time </label>
      <SelectButton
        id="confirmation"
        v-model="confirmation"
        :options="options"
        optionLabel="label"
        class="custom-select-button mb-4"
        :pt="{
          button: ({ context }) => ({ class: context.active ? 'bg-primary border-900' : undefined })
        }"
      />
      <Button type="submit" label="Submit" />
    </form>
  </div>
</template>

<script setup>
import { defineProps, defineEmits, ref, onMounted, watch, computed, watchEffect } from 'vue'
import { useField, useForm } from 'vee-validate'
import { useValidation } from '../../store/ValidationStore'
import { UseChannelStore } from '../../store/ChannelStore'

const formStore = useValidation()
const channelStore = UseChannelStore()
const { handleSubmit, resetForm } = useForm()
const slug = ref('')
const apiURL = ref('')
const adminToken = ref('')
const apiKey = ref('')
const apiSecret = ref('')
const confirmation = ref('')
const options = [
  { label: 'Yes', value: true },
  { label: 'No', value: false }
]
const LocaleName = ['EN', 'FR', 'IR']
const CurrencyName = ['USD', 'CAD', 'GBP', 'UPY']
const Types = ['Shopify', 'Woocommerce', 'Bigcommerce']
const emits = defineEmits(['handledRegistration'])
const { value: name, errorMessage: nameError } = useField('name', formStore.validateName)
const { value: Customer, errorMessage: customerError } = useField(
  'Customer',
  formStore.validateCustomer
)
const { value: Locale, errorMessage: localeError } = useField('Locale', formStore.validateLocale)
const { value: currency, errorMessage: currencyError } = useField(
  'currency',
  formStore.validateCurrency
)
const { value: URL, errorMessage: urlError } = useField('URL', formStore.validateURL)
const { value: type, errorMessage: typeError } = useField('type', formStore.validateType)
const { value: is_active, errorMessage: buttonError } = useField(
  'is_active',
  formStore.validateButton
)
watch(name, (newName) => {
  slug.value = channelStore.generateSlug(newName)
})

onMounted(() => {
  channelStore.fetchCustomers()
})

const handleCreateChannel = handleSubmit(async (value) => {
  try {
    const formdata = {
      name: name.value,
      slug: slug.value,
      customer_id: channelStore.selectedCustomerId,
      locale: Locale.value,
      currency: currency.value,
      URL: URL.value,
      type: type.value,
      api_url: apiURL.value,
      admin_token: adminToken.value,
      api_key: apiKey.value,
      api_secret: apiSecret.value,
      confirmation: confirmation.value.value,
      is_active: is_active.value.value
    }
    await channelStore.handleCreateChannel(formdata)

    if (channelStore.response) {
      emits('handledRegistration')
    }
  } catch (error) {
    console.error('Error in handleCreateChannel:', error)
  }
})

const { customer_id } = defineProps(['customer_id'])
const customerId = ref(customer_id)
console.log(customerId.value)
const findCustomerById = (data) => {
  return channelStore.customers.find((customer) => customer.id === data)
}
const aucompleteDisable = ref(false)
watchEffect(() => {
  if (customerId.value !== '') {
    console.log(customerId.value)
    let customerObj = findCustomerById(1)
    console.log(customerObj)
    if (customerObj && customerObj.name) {
      console.log(customerObj.name)
      Customer.value = customerObj.name
      channelStore.selectedCustomerId = customerObj.id
      aucompleteDisable.value = true
    }
  }
})
</script>

<style scoped>
.inputBox {
  width: 100%;
}
.p-error {
  margin-bottom: 10px;
}
</style>
