<?php

namespace App\Http\Controllers;

use App\Models\Event;
use App\Models\Note;
use App\Models\Organization;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;

class EventController extends Controller
{
    public function addEvent(Request $request): JsonResponse
    {
        try {
            $validator = Validator::make($request->all(), $this->getValidationRules());

            $validator->validate();
            $event = $this->createEvent($request->all());
            $this->createEventNote($event, $request->input('event_note'));
            return response()->json(['success' => 'Event added successfully'], 200);
        } catch (ValidationException $e) {
            return response()->json(['errors' => $e->errors()], 422);
        }
    }

    private function getValidationRules(): array
    {
        return [
            'event_name' => 'required|string|max:255|min:5',
            'organization_id' => 'required|exists:organizations,id',
            'event_description' => 'required|string',
            'event_location' => 'string|nullable',
            'tags' => 'nullable|string',
            'price' => 'required_if:pay_type,paid|numeric|min:500|max:3000|nullable',
            'start_date' => 'date|nullable',
            'end_date' => 'date|after_or_equal:start_date|nullable',
            'event_note' => 'required|string|max:255',
            'is_speaker' => 'nullable|boolean',
        ];
    }
    private function createEvent(array $eventData): Event
    {
        $event = new Event($eventData);
        $event->save();

        return $event;
    }

    private function createEventNote(Event $event, string $noteText): void
    {
        $note = new Note();
        $note->note = $noteText;
        $event->note()->save($note);
    }
    public function deleteEvent($id) : JsonResponse {
        $event = Event::find($id);
        $event->delete();
        return response()->json(['success' => 'Event deleted successfully'], 200);
        
    }
    public function editEvent($id){
        $event = Event::find($id);
        $organization= Organization::pluck('name','id');
        return view('editEvent',['event'=>$event,'organization'=>$organization]);
    }
    public function updateEvent(Request $request, $id){
        $validatedData = $request->validate($this->getValidationRules());
        // Update the event details in the database
        $event = Event::findOrFail($id);
        $event->update($validatedData);    
        return redirect()->route('home')->with('success', 'Event updated successfully');
    
    }

}