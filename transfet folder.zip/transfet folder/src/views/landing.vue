<template>
  <navigation />
  <div class="surface-ground p-d-flex p-ai-center p-jc-center">
    <div class="surface-popup p-card p-p-4">
      <router-link to="registration" class="p-button font-bold m-0 mt-5 text-xl lg:text-xl">
        Registration
      </router-link>
      <div class="container">
        <div class="p-text-2xl p-text-primary">Users List</div>
        <div class="p-datatable">
          <Toast />
          <Dialog v-model:visible="isEditing" modal header="Editing" :style="{ width: '50vw' }">
            <UserModal
              :isEditing="isEditing"
              :userToEdit="userData"
              @close="closeModal"
              @dataUpdated="handleDataUpdated"
            />
          </Dialog>
          <DataTable
            :value="data"
            paginator
            :rows="10"
            :rowsPerPageOptions="[10, 20, 30, 50]"
            tableStyle="min-width: 50rem"
          >
            <Column header="Index">
              <template #body="slotProps">
                {{ slotProps.index + 1 }}
              </template>
            </Column>
            <Column field="name" header="Name"></Column>
            <Column field="email" header="Email"></Column>
            <Column field="username" header="User Name"></Column>
            <Column header="Images">
              <template #body="slotProps">
                <img
                  :src="baseUrl + slotProps.data.img_url"
                  alt="Profile.."
                  style="width: 150px; height: 100px"
                />
              </template>
            </Column>
            <Column header="Actions">
              <template #body="slotProps">
                <span
                  class="pi pi-trash text-xl p-2 text-red-500 cursor-pointer"
                  @click.prevent="deleteUser(slotProps.data)"
                ></span>
                <span
                  class="pi pi-file-edit text-xl p-2 text-purple-500 cursor-pointer"
                  @click.prevent="editUser(slotProps.data)"
                ></span>
              </template>
            </Column>
          </DataTable>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useRouter, RouterLink } from 'vue-router'
import Toast from 'primevue/toast'
import UserModal from './UserModal.vue'

import { onMounted, ref } from 'vue'
import axios from 'axios'
import { useToast } from 'primevue/usetoast'
const data = ref([])
const isEditing = ref(false)
const userData = ref('')
const toast = useToast()
const baseUrl = 'http://127.0.0.1:8000'

const refreshDataTable = () => {
  axios
    .get(baseUrl + '/api/users')
    .then((response) => {
      data.value = response.data.Users
    })
    .catch((error) => {
      console.error(error)
    })
}

onMounted(() => {
  refreshDataTable()
})

const deleteUser = (user) => {
  axios.delete(baseUrl + `/api/user/${user.id}`).then((response) => {
    let message = response.data.message
    const index = data.value.findIndex((u) => u.id === user.id)
    if (index != -1 && response.status === 201) {
      data.value.splice(index, 1)
      toast.add({ severity: 'error', summary: 'Delete', detail: message, life: 2000 })
    } else {
      toast.add({ severity: 'warn', summary: 'Delete Error!', detail: message, life: 2000 })
    }
  })
}
const editUser = (user) => {
  isEditing.value = true
  userData.value = user
}
const handleDataUpdated = () => {
  toast.add({
    severity: 'success',
    summary: 'Updating Complete',
    detail: 'Data Updated Successfully!',
    life: 2000
  })
  closeModal()
  refreshDataTable()
}
const closeModal = () => {
  isEditing.value = false
  userData.value = null
}
</script>

<style scoped>
.surface-ground {
  height: auto;
  background-color: #f4f4f4;
  display: flex;
  align-items: center;
  justify-content: center;
}

.surface-popup {
  width: 100%;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  text-align: center;
}

.container {
  padding: 16px;
}

.p-text-primary {
  color: #007bff;
}

.p-text-2xl {
  font-size: 2rem;
}

.p-card {
  padding: 16px;
}

.p-mb-3 {
  margin-bottom: 1.5rem;
}
</style>
