$(document).ready(function () {
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
        },
    });

    var dataTable = $("#table").DataTable({
        paging: false,
        info: false,
        searching: false,
        columnDefs: [
            {
                targets: [0, 1, 2, 3, 4, 5, 9, 10, 11], // First column (index 0)
                orderable: false,
            },
        ],
        drawCallback: function (settings) {
            // Remove sorting classes from the first header cell
            $(this.api().table().header())
                .find("th")
                .eq(0)
                .removeClass("sorting_asc sorting_desc");
        },
    });
    $(document).ready(function () {
        // Event listener for the Apply button
        $("#batch-apply").click(function () {
            const selectedAction = $(".batch-select").val(); // Get the selected action
            const selectedCheckboxes = $(".checkboxes:checked"); // Get the selected checkboxes

            // Perform the selected action for each selected checkbox
            selectedCheckboxes.each(function () {
                const recordId = $(this).val(); // Get the value of the checkbox (record ID)

                // Perform the batch action based on the selected action
                if (selectedAction === "delete") {
                    $.ajax({
                        url: `/event/delete/${recordId}`,
                        type: "DELETE",
                        success: function (data) {
                            // Success callback
                            console.log("Record deleted:", data);
                            alertify.success(data.message);
                        },
                        error: function (error) {
                            // Error callback
                            console.error("Error deleting record:", error);
                        },
                    });
                } else if (selectedAction === "update status") {
                    // Perform update status action
                    // You might want to make an AJAX request to update the status of the record
                    $("#table").DataTable().draw();
                } else if (selectedAction === "Trash") {
                    // Perform Trash action
                    // You might want to make an AJAX request to move the record to trash
                    $("#table").DataTable().draw();
                }

                // Update the UI or show a message indicating that the action has been performed
            });
        });
    });
});
