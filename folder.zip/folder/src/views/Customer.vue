<template>
  <div class="root p-5">
    <div class="surface-ground">
      <div class="flex justify-content-between flex-wrap">
        <div class="flex justify-content-center align-item-center text-4xl text-black">
          Customers
        </div>
        <router-link to="/channel" :key="$route.fullPath">
          <Button>Channels</Button>
        </router-link>
        <div class="flex justify-content-center align-item-center">
          <Button @click="visible = !visible">Create Customer</Button>
        </div>
        <Dialog v-model:visible="visible" modal header="Create Customer" :style="{ width: '50vw' }">
          <CustomerForm :customer="editingCustomer" @handledRegistration="afterRegistration" @handleUpdate="afterUpdate" />
        </Dialog>
      </div>
      <div class="surface-section p-4 mt-3">
        <DataTable
          v-model:selection="selectedCustomers"
          :value="customerStore.Customers"
          dataKey="id"
          paginator
          :rows="10"
          :rowsPerPageOptions="[10, 20, 30, 50]"
          tableStyle="min-width: 50rem"
        >
          <Column selectionMode="multiple" headerStyle="width: 3rem"></Column>
          <Column field="name" header="Name"></Column>
          <Column field="country" header="Country"></Column>
          <Column header="Channel">
            <template #body="slotProps">
              <Tag severity="success" rounded class="px-4 py-1 text-xl">
                {{ slotProps.data.channels.length }}</Tag
              >
              <router-link :to="{ path: '/channel', query: { id: slotProps.data.id } }">
                <i class="pi pi-plus-circle px-2 text-xl"></i>
              </router-link>
            </template>
          </Column>
          <Column header="Is Active">
            <template #body="slotProps">
              <Tag severity="success" rounded class="px-3 py-1 text-sm">
                {{ slotProps.data.is_active ? 'YES' : 'NO' }}</Tag
              >
            </template>
          </Column>
          <Column header="Created At">
            <template #body="slotProps">
              <span
                >{{ customerStore.calculateElapsedTime(slotProps.data.created_at) }} Days Ago</span
              >
            </template>
          </Column>
          <Column header="Action">
            <template #body="{ data }">
              <span
                class="pi pi-trash text-xl p-2 text-red-500 cursor-pointer"
                @click.prevent="deleteCustomer(data.id)"
              ></span>
              <span
                class="pi pi-file-edit text-xl p-2 text-purple-500 cursor-pointer"
                @click.prevent="editCustomer(data)"
              ></span>
            </template>
          </Column>
        </DataTable>
        <Toast />
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import CustomerForm from './components/CustomerForm.vue'
import { useCustomerStore } from '../store/CustomerStore'
import axios from 'axios'
import Toast from 'primevue/toast'
import { useToast } from 'primevue/usetoast'

const toast = useToast()
const visible = ref(false)
const selectedCustomers = ref()
const metaKey = ref(true)
const editingCustomer = ref(null)
const customerStore = useCustomerStore()

onMounted(() => {
  customerStore.fetchCustomers()
})
const afterRegistration = () => {
  visible.value = false
  customerStore.fetchCustomers()
}
function deleteCustomer(id) {
  axios.delete(`http://127.0.0.1:8000/api/customers/${id}`).then((response) => {
    let message = response.data.message
    if (response.status === 200) {
      customerStore.deleteCustomer(id)
      toast.add({ severity: 'error', summary: 'Delete', detail: message, life: 2000 })
    } else {
      toast.add({ severity: 'warn', summary: 'Delete Error!', detail: message, life: 2000 })
    }
  })
}
function editCustomer(data) {
  editingCustomer.value = data
  visible.value = true
}
const afterUpdate = () =>{
  visible.value = false
  toast.add({ severity: 'success', summary: 'Update complete!', detail: 'Update successfull', life: 2000 })
}
</script>

<style scoped></style>
