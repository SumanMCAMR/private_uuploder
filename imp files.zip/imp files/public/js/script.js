$(document).ready(function () {
    $("#add-organization").click(function () {
        $("#modal-add-organization").addClass("is-active");
    });
    $("#add-event").click(function () {
        $("#modal-add-event").addClass("is-active");
    });

    let errorBox = [
        "event_nameError",
        "organization_idError",
        "event_descriptionError",
        "event_locationError",
        "start_dateError",
        "end_dateError",
        "event_noteError",
    ];
    $(".modal-close,.cancel").click(function () {
        $("#add-organization-form")[0].reset();
        $.each(errorBox, function (index, error) {
            $("#" + error).text("");
        });
        $("#modal-add-organization").removeClass("is-active");
        alertify.error("cancelled");
    });
    $(document).on("click", "#close-event, #cancelButtonEvent", function (e) {
        e.preventDefault();
        $("#add-event-form")[0].reset();
        $.each(errorBox, function (index, error) {
            $("#" + error).text("");
        });
        $("#modal-add-event").removeClass("is-active");
        alertify.error("cancelled");
        console.log("cancelled");
    });

    // -----------submit function for organization----------------
    $("#add-organization-form").submit("click", function (e) {
        e.preventDefault();
        let formdata = new FormData(this);
        console.log(formdata);
        $.ajax({
            url: "/org/add",
            method: "POST",
            processData: false,
            contentType: false,
            data: formdata,
            success: function (response) {
                if (response) {
                    $("#add-organization-form")[0].reset();
                    $("#modal-add-organization").removeClass("is-active");
                    alertify.success(response.success);
                } else {
                    console.log("Unexpected response format");
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    console.log(errors);
                    $.each(errors, function (field, error) {
                        $("#" + field + "Error").text(error[0]);
                        console.log(error[0]);
                    });
                } else {
                    console.log(xhr);
                }
            },
        });
    });

    //------------submit function for Events-------

    $("#add-event-form").on("click", "#event-publish", function (e) {
        e.preventDefault();
        // Extract tags and convert to comma-separated string
        var input = document.querySelector("#tag-input");
        var tagsArray = JSON.parse(input.value);
        var tagValues = tagsArray.map((tag) => tag.value);
        var tagsString = tagValues.join(", ");
        // Set modified tags data in FormData
        let formdata = new FormData($("#add-event-form")[0]);
        formdata.set("tags", tagsString); // Replace 'tags' with the actual field name

        $.ajax({
            url: "/event/add",
            method: "POST",
            processData: false,
            contentType: false,
            data: formdata,
            success: function (response) {
                console.log(response);
                console.log("clicked");
                if (response) {
                    $("#add-event-form")[0].reset();
                    $("#modal-add-event").removeClass("is-active");
                    alertify.success(response.success);
                    console.log(response.success);
                } else {
                    console.log("Unexpected response format");
                }
            },
            error: function (xhr) {
                if (xhr.status === 422) {
                    let errors = xhr.responseJSON.errors;
                    console.log(errors);
                    $.each(errors, function (field, error) {
                        $("#" + field + "Error").text(error[0]);
                        console.log(error[0]);
                    });
                } else {
                    console.log(xhr);
                }
            },
        });
    });
});
