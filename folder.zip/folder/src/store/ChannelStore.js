import { defineStore } from 'pinia'
import axios from 'axios'

export const UseChannelStore = defineStore('ChannelStore', {
  state: () => ({
    customers: [],
    filteredCustomers: [],
    response: false,
    selectedCustomerId: '',
    channels: []
  }),
  actions: {
    fetchCustomers() {
      axios.get('http://127.0.0.1:8000/api/customer-names').then((response) => {
        console.log(response)
        this.customers = response.data.customer_names
      })
    },
    search(event) {
      const maxSuggestions = 5
      this.filteredCustomers = this.customers
        .filter((customer) => customer.name.toLowerCase().startsWith(event.query.toLowerCase()))
        .slice(0, maxSuggestions)
    },
    generateSlug(str) {
      return str.toLowerCase().replace(/\s+/g, '-')
    },
    async handleCreateChannel(data) {
      return new Promise((resolve, reject) => {
        axios
          .post('http://127.0.0.1:8000/api/channels', data)
          .then((response) => {
            console.log(response)
            if (response.status === 201) {
              this.response = true
              resolve(response)
            } else {
              reject(new Error('Failed to create channel'))
            }
          })
          .catch((error) => {
            console.error(error)
            reject(error)
          })
      })
    },
    handleCustomerSelect(event) {
      let selectedCustomer = event.value
      this.selectedCustomerId = selectedCustomer.id
    },
    fetchChannels() {
      axios.get('http://127.0.0.1:8000/api/channels').then((response) => {
        console.log(response)
        this.channels = response.data.channels
      })
    },
    calculateElapsedTime(createdAt) {
      console.log('createdAt:', createdAt)
      const createdDate = new Date(createdAt)
      const currentDate = new Date()
      const timeDifferenceInMilliseconds = currentDate - createdDate
      return Math.floor(timeDifferenceInMilliseconds / (1000 * 60 * 60 * 24))
    }
  }
})
