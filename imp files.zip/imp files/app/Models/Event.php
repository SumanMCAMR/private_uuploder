<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $fillable=['event_name','organization_id','event_description','event_location','tags','price','start_date','end_date','is_speaker'];
    use HasFactory;
    public function note(){
        return $this->morphOne(Note::class,'notable');
    }
    public function organization(){
        return $this->belongsTo(Organization::class);
    }

}