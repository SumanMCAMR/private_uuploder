<template>
  <div class="root p-5">
    <div class="surface-ground">
      <div class="flex justify-content-between flex-wrap">
        <div class="flex justify-content-center align-item-center text-4xl text-black">
          Customers
        </div>
        <div class="flex justify-content-center align-item-center">
          <Button @click="visible = !visible">Create Customer</Button>
        </div>
        <Dialog v-model:visible="visible" modal header="Create Customer" :style="{ width: '50vw' }">
          <CustomerForm @handledRegistration="afterRegistration" />
        </Dialog>
      </div>
      <div class="surface-section p-4 mt-3">
        <DataTable
          v-model:selection="selectedCustomers"
          :value="customerStore.Customers"
          dataKey="id"
          paginator
          :rows="10"
          :rowsPerPageOptions="[10, 20, 30, 50]"
          tableStyle="min-width: 50rem"
        >
          <Column selectionMode="multiple" headerStyle="width: 3rem"></Column>
          <Column field="name" header="Name"></Column>
          <Column field="country" header="Country"></Column>
          <Column header="Channel">
            <template #body="slotProps">
              {{ slotProps.data.length }}
            </template>
          </Column>
          <Column field="is_active" header="Is Active"></Column>
          <Column header="Created At">
            <template #body="slotProps">
              <span>{{ calculateElapsedTime(slotProps.data.created_at) }}</span>
            </template>
          </Column>
          <Column header="Action">
            <template #body="slotProps">
              <span
                class="pi pi-trash text-xl p-2 text-red-500 cursor-pointer"
                @click.prevent="slotProps.data;"
              ></span>
              <span
                class="pi pi-file-edit text-xl p-2 text-purple-500 cursor-pointer"
                @click.prevent="slotProps.data;"
              ></span>
            </template>
          </Column>
        </DataTable>
      </div>
    </div>
  </div>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import CustomerForm from './components/CustomerForm.vue'
import { useCustomerStore } from '../store/CustomerStore'
import axios from 'axios'

const visible = ref(false)
const selectedCustomers = ref()
const metaKey = ref(true)
const customerStore = useCustomerStore()

onMounted(() => {
  customerStore.fetchCustomers()
})

const calculateElapsedTime = (createdAt) => {
  console.log('createdAt:', createdAt)
  const createdDate = new Date(createdAt)
  const currentDate = new Date()
  const timeDifferenceInMilliseconds = currentDate - createdDate
  const daysElapsed = Math.floor(timeDifferenceInMilliseconds / (1000 * 60 * 60 * 24))
  return daysElapsed
}

const afterRegistration = () => {
  visible.value = false
  customerStore.fetchCustomers()
}
</script>

<style scoped></style>
