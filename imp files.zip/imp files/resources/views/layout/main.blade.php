<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="{{ csrf_token() }}"> {{-- for ajax --}}
    <title>@yield('title')</title>
    @include('partials.style')
    @include('partials.script')
    @push('script')
        <script src="https://cdn.jsdelivr.net/npm/alertifyjs@1.13.1/build/alertify.min.js"></script>
    @endpush
</head>
<body>
<header>@include('partials.header')</header>
<main>
    @yield('content')
</main>
<section>
    @yield('hero')
</section>
</body>
</html>