@extends('layout.main') @section('title') Home page @endsection
@section('content')
<section class="section">
    <div class="container">
        <div class="header-content p-2 mb-4">
            <span class="title has-text-primary mr-5">Events & Organizations</span>
            <span class="button is-info is-hovarable" id="add-event"><strong>Add Events</strong></span>
            <span class="button is-primary is-hovarable" id="add-organization"><strong>Add org</strong></span>
        </div>
        <div class="filter has-background-primary-light pl-4 mb-5 mt-5">
            <span>Filter By :</span>
        </div>
    </div>
</section>

{{-- ---------------add organization modal-----------}}
<div id="modal-add-organization" class="modal">
    <div class="modal-background"></div>

    <div class="modal-content">
        <div class="box">
            <h1 class="title is-4 has-text-primary">Add Organization</h1>
            <div class="form">
                <form id="add-organization-form">
                    <div class="field">
                        @csrf
                        <label class="label">Org Name</label>
                        <div class="control">
                            <input class="input" type="text" name="name" value="{{ old('name') }}" required />
                        </div>
                        <span class="help has-text-danger" id="nameError"></span>
                    </div>
                    <div class="field">
                        <label class="label">Address</label>
                        <div class="control">
                            <input class="input" type="text" name="address" value="{{ old('address') }}" required />
                        </div>
                        <span class="help has-text-danger" id="addressError"></span>
                    </div>
                    <div class="field">
                        <label class="label">Notes</label>
                        <div class="control">
                            <input class="input" type="text" name="note" value="{{ old('note') }}" required />
                        </div>
                        <span class="help has-text-danger" id="noteError"></span>
                    </div>
                    <div class="field">
                        <label class="label">Slug</label>
                        <div class="control">
                            <input class="input" type="text" name="slug" value="{{ old('Slug') }}" required />
                        </div>
                        <span class="help has-text-danger" id="slugError"></span>
                    </div>
                    <div class="field is-grouped">
                        <div class="control">
                            <button class="button is-primary">Save</button>
                        </div>
                        <div class="control">
                            <button class="button is-link cancel" type="button">
                                Cancel
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <button class="modal-close is-large" aria-label="close"></button>
</div>
<script src="js/event-js.js"></script>
<script src="js/script.js"></script>
{{-- ---------------end organization modal-----------}}

{{-- ---------------add event modal-----------}}
<div class="modal" id="modal-add-event">
    <form id="add-event-form">
        @csrf
        <div class="modal-background"></div>
        <div class="modal-card">
            <header class="modal-card-head">
                <p class="modal-card-title">Create an Event</p>
                <button class="delete" id="close-event" aria-label="close"></button>
            </header>
            <section class="modal-card-body">
                <div class="field">
                    <label class="label" for="event_name">Event Name</label>
                    <div class="control">
                        <input class="input" id="event_name" name="event_name" type="text" />
                        <span class="help is-danger" id="event_nameError"></span>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Organization Name</label>
                    <div class="control">
                        <div class="select">
                            <select name="organization_id">
                                <option value="" disabled selected>
                                    Select an organization
                                </option>
                                @foreach ($organization as $id => $name)
                                <option value="{{ $id }}">{{ $name }}</option>
                                @endforeach
                            </select>
                            <span class="help is-danger" id="organization_idError"></span>
                        </div>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Event Description</label>
                    <div class="control">
                        <label>
                            <textarea class="textarea" name="event_description"></textarea>
                        </label>
                        <span class="help is-danger" id="event_descriptionError"></span>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Event Type</label>
                    <div class="buttons has-addons">
                        <button class="button" type="button" id="inPerson" name="event_type" value="in_person">
                            In-person
                        </button>
                        <button class="button" type="button" id="virtual" name="event_type" value="virtual">
                            Virtual
                        </button>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Location</label>
                    <div class="control">
                        <input class="input locationBox" name="event_location" type="text" />
                        <span class="help is-danger" id="event_locationError"></span>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Topic</label>
                    <div class="control">
                        <input class="input" type="text" name="tags" id="tag-input" placeholder="Enter tags..." />
                    </div>
                </div>
                <div class="field">
                    <label class="label">Price</label>
                    <div class="buttons has-addons">
                        <button class="button" type="button" id="paidButton" name="pay_type" value="paid">Paid
                        </button>
                        <button class="button" type="button" id="freeButton" name="pay_type" value="free">Free
                        </button>
                    </div>
                    <div class="control">
                        <span class="help">Please choose the range between 500 to 3000</span>
                        <input class="slider sliderBox" type="range" name="price" min="500" max="3000" />
                    </div>
                </div>
                <div class="field">
                    <label class="label">Event Date</label>
                    <div class="buttons has-addons">
                        <button class="button" type="button" id="eventDate" name="event_date" value="known">Event
                            Date
                        </button>
                        <button class="button" type="button" id="unknown" name="event_date" value="unknown">
                            Unknown
                        </button>
                    </div>
                    <div class="field is-grouped" id="dateInputBoxes">
                        <div class="control">
                            <input class="input eventDate" name="start_date" type="date" />
                            <span class="help is-danger" id="start_dateError"></span>
                        </div>
                        <div class="control">
                            <input class="input eventDate" name="end_date" type="date" />
                            <span class="help is-danger" id="end_dateError"></span>
                        </div>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Notes</label>
                    <div class="control">
                        <input class="input" type="text" name="event_note" />
                        <span class="help is-danger" id="event_noteError"></span>
                    </div>
                </div>
                <div class="field">
                    <label class="label">Accept Speaker Application?</label>
                    <div class="control">
                        <label class="checkbox">
                            <input type="checkbox" name="is_speaker" value="1" />
                            Yes
                        </label>
                    </div>
                </div>

            </section>
            <footer class="modal-card-foot">
                <button class="button is-primary" type="button" id="event-publish">Publish</button>
                <button class="button" id="cancelButtonEvent" type="button">Cancel</button>
            </footer>
        </div>
    </form>
</div>
<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify"></script>
<script src="https://cdn.jsdelivr.net/npm/@yaireo/tagify/dist/tagify.polyfills.min.js"></script>
@endsection

{{------------------Code for data tables-----------------------}}

@section('hero')
<section class="section">
    <div class="container">
        <div class="header-content p-4 mb-4">
            <span class="title has-text-primary mr-5">Events Details</span>
        </div>
        <script src="js/batch-action.js"></script>
        <div class="batch-action pb-4">
            <div class="field has-addons">
                <div class="control">
                    <div class="select">
                        <select class="batch-select select">
                            <option value="" disabled selected>Batch Action</option>
                            <option value="delete">Delete</option>
                            <option value="update status">Update status</option>
                            <option value="Trash">Trash</option>
                        </select>
                    </div>
                </div>
                <div class="control">
                    <button class="button is-primary" id="batch-apply">Apply</button>
                </div>
            </div>
        </div>

        <table class="table table is-bordered is-striped is-narrow is-hoverable is-fullwidth responsive" id="table">
            <thead class="thead">
                <tr>
                    <th class="has-text-centered"><label for="selectAll">Select All</label>
                        <input type="checkbox" id="selectAll" name="selectAll">
                    </th>
                    <th class="has-text-centered">Event Name</th>
                    <th class="has-text-centered">Organization Name</th>
                    <th class="has-text-centered">Event Description</th>
                    <th class="has-text-centered">Event Location</th>
                    <th class="has-text-centered">Tags</th>
                    <th class="has-text-centered">Price</th>
                    <th class="has-text-centered">Start Date</th>
                    <th class="has-text-centered">End Date</th>
                    <th class="has-text-centered">Notes</th>
                    <th class="has-text-centered">Has Speaker</th>
                    <th class="has-text-centered">Actions</th>
                </tr>
            </thead>
            <tbody class="tbody striped">
                @foreach($events as $event)
                <tr>
                    <td class="has-text-centered"><input type="checkbox" class="checkboxes" value="{{$event->id}}"></td>
                    <td>{{$event->event_name}}</td>
                    <td>{{$event->organization->name}}</td>
                    <td>{{$event->event_description}}</td>
                    <td>{{$event->event_location}}</td>
                    <td>
                        {{$event->tags}}
                    </td>
                    <td>{{$event->price}}</td>
                    <td>{{$event->start_date}}</td>
                    <td>{{$event->end_date}}</td>
                    <td>{{$event->note->note}}</td>
                    <td>{{ $event->is_speaker ? 'true' : 'false' }}</td>
                    <td class="has-text-centered">
                        <a href=""
                            onclick="event.preventDefault(); document.getElementById('delete-form-{{$event->id}}').submit();">
                            <span class="icon has-text-danger">
                                <i class="fas fa-trash-alt"></i>
                            </span>
                        </a>
                        <form id="delete-form-{{$event->id}}" action="{{ route('deleteEvent', ['id' => $event->id]) }}"
                            method="POST" style="display: none;">
                            @csrf
                            @method('DELETE')
                        </form>

                        <a href="{{ route('editEvent', ['id' => $event->id]) }}">
                            <span class="icon has-text-info">
                                <i class="fas fa-edit"></i>
                            </span>
                        </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
    </div>
</section>
@endsection