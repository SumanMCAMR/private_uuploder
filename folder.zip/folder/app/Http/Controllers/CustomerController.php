<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use http\Env\Response;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function store(Request $request): \Illuminate\Http\JsonResponse
    {
        $validatedData = $request->validate([
            'name' => ['required'],
            'slug' => ['required'],
            'country' => ['required'],
            'is_active' => ['required']
        ]);
        if ($validatedData) {
            $customer = Customer::create($validatedData);
            if ($customer) {
                return response()->json(['message' => 'Customer created successfully', 'customer' => $customer], 201);
            } else {
                return response()->json(['message' => 'Failed to create Customer'], 500);
            }
        } else {
            return response()->json(['message' => 'Validation error', 'errors' => $request->errors()], 400);
        }
    }
    public function index(): \Illuminate\Http\JsonResponse
    {
        $customers = Customer::with('channels')->get();
        if($customers){
            return response()->json(['message' => 'Customers retrieved successfully', 'customers' => $customers], 200);
        }else{
            return response()->json(['message'=>'Error fetching customers right now😔'],404);
        }
    }
    public function getCustomerNames(): \Illuminate\Http\JsonResponse
{
    $customerNamesWithIds = Customer::all(['id','name']);
    return response()->json(['customer_names' => $customerNamesWithIds], 200);
}

    public function update(Request $request, $id): \Illuminate\Http\JsonResponse
{
    $customer = Customer::find($id);

    if (!$customer) {
        return response()->json(['message' => 'Customer not found'], 404);
    }

    $validatedData = $request->validate([
        'name' => ['required'],
        'slug' => ['required'],
        'country' => ['required'],
        'is_active' => ['required']
    ]);

    if ($validatedData) {
        $customer->update($validatedData);
        return response()->json(['message' => 'Customer updated successfully', 'customer' => $customer], 200);
    } else {
        return response()->json(['message' => 'Validation error', 'errors' => $request->errors()], 400);
    }
}
public function destroy($id): \Illuminate\Http\JsonResponse
{
    $customer = Customer::find($id);

    if (!$customer) {
        return response()->json(['message' => 'Customer not found'], 404);
    }

    $customer->delete();

    return response()->json(['message' => 'Customer deleted successfully'], 200);
}
public function show($id): \Illuminate\Http\JsonResponse
{
    $customer = Customer::with('channels')->find($id);

    if (!$customer) {
        return response()->json(['message' => 'Customer not found'], 404);
    }

    return response()->json(['message' => 'Customer retrieved successfully', 'customer' => $customer], 200);
}
}
