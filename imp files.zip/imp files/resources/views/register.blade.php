@extends('layout.main')
@section('content')
    <div class="section bg-gray-200">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-half bg-white rounded">
                    @if($errors->has('error'))
                        <span class="notification has-text-danger has-text-centered">{{$errors->first('error')}}</span>
                    @endif
                    <form action="{{route('register')}}" method="post">@csrf
                        <div class="field">
                            <p class="control has-icons-left has-icons-right">
                                <input class="input" name="name" type="text" placeholder="Name">
                                <span class="icon is-small is-left">
                                  <i class="fas fa-user"></i>
                                </span>
                                <span class="icon is-small is-right">
                                  <i class="fas fa-check"></i>
                                </span>
                                @if($errors->has('name'))
                                    <span class="help has-text-danger">{{$errors->first('name')}}</span>
                                @endif
                            </p>
                        </div>
                        <div class="field">
                            <p class="control has-icons-left has-icons-right">
                                <input class="input" name="email" type="email" placeholder="Email">
                                <span class="icon is-small is-left">
                              <i class="fas fa-envelope"></i>
                            </span>
                                <span class="icon is-small is-right">
                              <i class="fas fa-check"></i>
                            </span>
                                @if($errors->has('email'))
                                    <span class="help has-text-danger">{{$errors->first('email')}}</span>
                                @endif
                            </p>
                        </div>
                        <div class="field">
                            <p class="control has-icons-left">
                                <input class="input" name="password" type="password" placeholder="Password">
                                <span class="icon is-small is-left">
                                  <i class="fas fa-lock"></i>
                                </span>
                            </p>
                            @if($errors->has('password'))
                                <span class="help has-text-danger">{{$errors->first('password')}}</span>
                            @endif
                        </div>
                        <div class="field">
                            <p class="control">
                                <button class="button is-success">
                                    Login
                                </button>
                            </p>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>
@endsection