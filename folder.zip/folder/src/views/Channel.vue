<template>
  <div class="root p-5">
    <div class="surface-ground">
      <div class="flex justify-content-between flex-wrap">
        <div class="flex justify-content-center align-item-center text-4xl text-black">
          Channels
        </div>
        <router-link to="/" :key="$route.fullPath">
          <Button>Customers</Button>
        </router-link>
        <div class="flex justify-content-center align-item-center">
          <Button @click="visible = !visible">Create Channel</Button>
        </div>
        <Dialog
          v-model:visible="visible"
          modal
          header="Create Channel"
          @after-hide="closingModal"
          :style="{ width: '50vw' }"
        >
          <ChannelForm @handledRegistration="afterRegistration" :customer_id="customerId" />
        </Dialog>
      </div>
      <div class="surface-section p-4 mt-3">
        <DataTable
          v-model:selection="selectedChannels"
          :value="channelStore.channels"
          dataKey="id"
          paginator
          :rows="10"
          :rowsPerPageOptions="[10, 20, 30, 50]"
          tableStyle="min-width: 50rem"
        >
          <Column selectionMode="multiple" headerStyle="width: 3rem"></Column>
          <Column field="name" header="Name"></Column>
          <Column field="customer.name" header="Customer Name"></Column>
          <Column field="is_active" header="Is Active"></Column>
          <Column header="Created At">
            <template #body="slotProps">
              <span
                >{{ channelStore.calculateElapsedTime(slotProps.data.created_at) }} Days ago</span
              >
            </template>
          </Column>
          <Column header="Action">
            <template #body="{ data }">
              <span
                class="pi pi-trash text-xl p-2 text-red-500 cursor-pointer"
                @click.prevent="deleteChannel(data.id)"
              ></span>
              <span
                class="pi pi-file-edit text-xl p-2 text-purple-500 cursor-pointer"
                @click.prevent=""
              ></span>
            </template>
          </Column>
        </DataTable>
        <Toast />
      </div>
    </div>
  </div>
</template>

<script setup>
import { onMounted, ref } from 'vue'
import ChannelForm from './components/ChannelForm.vue'
import { UseChannelStore } from '../store/ChannelStore'
import { useRoute, useRouter } from 'vue-router'
import Toast from 'primevue/toast'
import { useToast } from 'primevue/usetoast'
import axios from 'axios'

const channelStore = UseChannelStore()
const visible = ref(false)
const products = ref()
const selectedChannels = ref()
const metaKey = ref(true)
const customerId = ref('')
const route = useRoute()
const router = useRouter()
const toast = useToast()

onMounted(async () => {
  channelStore.fetchChannels()
  handleQuery()
})
const handleQuery = () => {
  const customer_id = route.query.id
  console.log('customer_id ' + customerId)
  if (customer_id) {
    customerId.value = customer_id
    visible.value = true
  }
}

function closingModal() {
  if (route.query.id) {
    const { id, ...queryWithoutId } = route.query
    router.replace({ query: queryWithoutId })
  }
}

const afterRegistration = () => {
  visible.value = false
  channelStore.fetchChannels()
}
function deleteChannel(id) {
  axios
    .delete(`http://127.0.0.1:8000/api/channels/${id}`)
    .then((response) => {
      let message = response.data.message
      if (response.status === 200) {
        channelStore.channels = channelStore.channels.filter((channel) => channel.id !== id)
        toast.add({ severity: 'success', summary: 'Delete', detail: message, life: 2000 })
      } else {
        toast.add({ severity: 'warn', summary: 'Delete Error!', detail: message, life: 2000 })
      }
    })
    .catch((error) => {
      console.error(error)
      toast.add({
        severity: 'error',
        summary: 'Delete Error!',
        detail: 'An error occurred while deleting the channel',
        life: 2000
      })
    })
}
</script>

<style scoped></style>
