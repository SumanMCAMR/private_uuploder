<?php

use App\Http\Controllers\CustomerController;
use App\Http\Controllers\ChannelController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;


Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/customers',[CustomerController::class,'store']);
Route::get('/customers',[CustomerController::class,'index']);
Route::get('/customer-names', [CustomerController::class, 'getCustomerNames']);
Route::get('/customers/{id}', [CustomerController::class, 'show']);
Route::put('/customers/{id}', [CustomerController::class, 'update']);
Route::delete('/customers/{id}', [CustomerController::class, 'destroy']);


// Create a new Channel
Route::post('/channels', [ChannelController::class, 'store']);

// Read all Channels
Route::get('/channels', [ChannelController::class, 'index']);

// Read a specific Channel by ID
Route::get('/channels/{id}', [ChannelController::class, 'show']);

// Update a specific Channel by ID
Route::put('/channels/{id}', [ChannelController::class, 'update']);

// Delete a specific Channel by ID
Route::delete('/channels/{id}', [ChannelController::class, 'destroy']);

