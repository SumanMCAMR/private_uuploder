@extends('layout.main')
@section('content')
    <div class="section bg-gray-200">
        <div class="container">
            <div class="columns is-centered">
                <div class="column is-half bg-white rounded">
                    <div class="is-flex is-justify-content-center mb-4">
                        @error('error')
                        <span class="notification is-danger is-light">{{$message}}</span>
                        @enderror
                    </div>
                    <form action="{{route('login')}}" method="post">@csrf
                        <div class="field">
                            <p class="control has-icons-left has-icons-right">
                                <input class="input" type="email" name="email" placeholder="Email"
                                       value="{{old('email')}}">
                                <span class="icon is-small is-left">
                            <i class="fas fa-envelope"></i>
                            </span>
                                <span class="icon is-small is-right">
                            <i class="fas fa-check"></i>
                            </span>
                                <span class="help has-text-danger">{{$errors->first('email')}}</span>
                            </p>
                        </div>
                        <div class="field">
                            <p class="control has-icons-left">
                                <input class="input" type="password" name="password" placeholder="Password">
                                <span class="icon is-small is-left">
                            <i class="fas fa-lock"></i>
                            </span>
                                <span class="help has-text-danger">{{$errors->first('password')}}</span>
                            </p>
                        </div>
                        <div class="field">
                            <p class="control">
                                <button id="loginbutton" class="button is-success">
                                    Login
                                </button>
                            </p>
                        </div>
                    </form>
                </div>
            </div>

        </div>
    </div>

@endsection